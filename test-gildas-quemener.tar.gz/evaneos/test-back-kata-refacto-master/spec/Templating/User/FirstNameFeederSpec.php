<?php

namespace spec\App\Templating\User;

use App\Templating\User\FirstNameFeeder;
use PhpSpec\ObjectBehavior;
use Prophecy\Argument;
use App\Templating\PlaceholderFeeder;
use App\Entity\User;
use App\Context\ApplicationContext;

class FirstNameFeederSpec extends ObjectBehavior
{
    function let(ApplicationContext $appContext)
    {
        $this->beConstructedWith($appContext);
    }

    function it_is_a_placeholder_feeder()
    {
        $this->shouldBeAnInstanceOf(PlaceholderFeeder::class);
    }

    function it_supports_text_with_first_name_placeholder_and_a_provided_user(
        User $user
    ) {
        $this->supports('foo [user:first_name] bar', ['user' => $user])->shouldReturn(true);
    }

    function it_supports_text_with_first_name_placeholder_and_no_provided_user(
        User $user
    ) {
        $this->supports('foo [user:first_name] bar', [])->shouldReturn(true);
    }

    function it_does_not_support_text_not_containing_a_first_name_placeholder()
    {
        $this->supports('foo bar', [])->shouldReturn(false);
    }

    function it_feeds_first_name_placeholder_using_provided_user(
        User $user
    ) {
        $user->firstname = 'Gildas';

        $this->feed('foo [user:first_name] bar', ['user' => $user])->shouldReturn('foo Gildas bar');
    }

    function it_feeds_first_name_placeholder_retrieving_user_from_application_context(
        User $user,
        $appContext
    ) {
        $appContext->getCurrentUser()->willReturn($user);
        $user->firstname = 'Gildas';

        $this->feed('foo [user:first_name] bar', [])->shouldReturn('foo Gildas bar');
    }
}
