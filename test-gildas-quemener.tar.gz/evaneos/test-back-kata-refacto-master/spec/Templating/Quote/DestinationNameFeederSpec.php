<?php

namespace spec\App\Templating\Quote;

use App\Templating\Quote\DestinationNameFeeder;
use PhpSpec\ObjectBehavior;
use Prophecy\Argument;
use App\Templating\PlaceholderFeeder;
use App\Entity\Quote;
use App\Repository\DestinationRepository;
use App\Entity\Destination;

class DestinationNameFeederSpec extends ObjectBehavior
{
    function let(DestinationRepository $repository)
    {
        $this->beConstructedWith($repository);
    }

    function it_is_a_placeholder_feeder()
    {
        $this->shouldBeAnInstanceOf(PlaceholderFeeder::class);
    }

    function it_supports_text_with_destination_name_placeholder_and_a_provided_quote(
        Quote $quote
    ) {
        $this->supports('foo [quote:destination_name] bar', ['quote' => $quote])->shouldReturn(true);
    }

    function it_does_not_support_text_not_containing_a_destination_name_placeholder()
    {
        $this->supports('foo bar', [])->shouldReturn(false);
    }

    function it_does_not_support_a_destination_name_placeholder_without_a_quote()
    {
        $this->supports('foo [quote:destination_name] bar', [])->shouldReturn(false);
    }

    function it_feeds_destination_name_placeholder(
        Quote $quote,
        Destination $destination,
        $repository
    ) {
        $quote->destinationId = 305;
        $repository->getById(305)->willReturn($destination);
        $destination->countryName = 'Argentine';

        $this->feed('foo [quote:destination_name] bar', ['quote' => $quote])->shouldReturn('foo Argentine bar');
    }
}
