<?php

namespace spec\App\Templating\Quote;

use PhpSpec\ObjectBehavior;
use Prophecy\Argument;
use App\Templating\PlaceholderFeeder;
use App\Entity\Quote;

class TextSummaryFeederSpec extends ObjectBehavior
{
    function it_is_a_placeholder_feeder()
    {
        $this->shouldBeAnInstanceOf(PlaceholderFeeder::class);
    }

    function it_supports_text_with_text_summary_placeholder_and_a_provided_quote(
        Quote $quote
    ) {
        $this->supports('foo [quote:summary] bar', ['quote' => $quote])->shouldReturn(true);
    }

    function it_does_not_support_text_not_containing_an_text_summary_placeholder()
    {
        $this->supports('foo bar', [])->shouldReturn(false);
    }

    function it_does_not_support_an_text_summary_placeholder_without_a_quote()
    {
        $this->supports('foo [quote:summary] bar', [])->shouldReturn(false);
    }

    function it_feeds_text_summary_placeholder(
        Quote $quote
    ) {
        $quote->id = 15;

        $this->feed('foo [quote:summary] bar', ['quote' => $quote])->shouldReturn('foo 15 bar');
    }
}
