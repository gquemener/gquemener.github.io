<?php

namespace spec\App\Templating\Quote;

use PhpSpec\ObjectBehavior;
use Prophecy\Argument;
use App\Repository\QuoteRepository;
use App\Repository\SiteRepository;
use App\Repository\DestinationRepository;
use App\Templating\Quote\DestinationLinkFeeder;
use App\Templating\PlaceholderFeeder;
use App\Entity\Quote;
use App\Entity\Destination;
use App\Entity\Site;

class DestinationLinkFeederSpec extends ObjectBehavior
{
    function let(
        QuoteRepository $quoteRepository,
        DestinationRepository $destinationRepository,
        SiteRepository $siteRepository
    ) {
        $this->beConstructedWith(
            $quoteRepository,
            $destinationRepository,
            $siteRepository
        );
    }

    function it_is_a_placeholder_feeder()
    {
        $this->shouldBeAnInstanceOf(PlaceholderFeeder::class);
    }

    function it_supports_text_with_destination_link_placeholder_and_a_provided_quote(
        Quote $quote
    ) {
        $this->supports('foo [quote:destination_link] bar', ['quote' => $quote])->shouldReturn(true);
    }

    function it_does_not_support_text_not_containing_a_destination_link_placeholder()
    {
        $this->supports('foo bar', [])->shouldReturn(false);
    }

    function it_does_not_support_a_destination_link_placeholder_without_a_quote()
    {
        $this->supports('foo [quote:destination_link] bar', [])->shouldReturn(false);
    }

    function it_feeds_destination_link_placeholder(
        Quote $quote,
        Destination $destination,
        Site $site,
        $quoteRepository,
        $destinationRepository,
        $siteRepository
    ) {
        $quote->id = 15;
        $quote->destinationId = 42;
        $quote->siteId = 87;

        $site->url = 'https://evaneos.fr';

        $destination->countryName = 'argentine';

        $quoteRepository->getById(15)->willReturn($quote);
        $destinationRepository->getById(42)->willReturn($destination);
        $siteRepository->getById(87)->willReturn($site);

        $this->feed('foo [quote:destination_link] bar', ['quote' => $quote])->shouldReturn('foo https://evaneos.fr/argentine/quote/15 bar');
    }
}
