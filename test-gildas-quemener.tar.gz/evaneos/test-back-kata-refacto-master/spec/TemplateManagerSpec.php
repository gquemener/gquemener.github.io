<?php

namespace spec\App;

use App\TemplateManager;
use PhpSpec\ObjectBehavior;
use Prophecy\Argument;
use App\Templating\PlaceholderFeeder;
use App\Entity\Template;

class TemplateManagerSpec extends ObjectBehavior
{
    function it_delegates_placeholders_feeding_to_relevant_feeders(
        PlaceholderFeeder $aFeeder,
        PlaceholderFeeder $anotherFeeder,
        PlaceholderFeeder $anIrrelevantFeeder,
        Template $template
    ) {
        $template->subject = 'Subject';
        $template->content = 'Content';

        $aFeeder->supports(Argument::cetera())->willReturn(true);
        $anotherFeeder->supports(Argument::cetera())->willReturn(true);
        $anIrrelevantFeeder->supports(Argument::cetera())->willReturn(false);

        $aFeeder->feed('Subject', ['foo' => 'bar'])->willReturn('aSubject');
        $aFeeder->feed('Content', ['foo' => 'bar'])->willReturn('aContent');
        $anotherFeeder->feed('aSubject', ['foo' => 'bar'])->willReturn('aSubjectWithAnotherSubject');
        $anotherFeeder->feed('aContent', ['foo' => 'bar'])->willReturn('aContentWithAnotherContent');
        $anIrrelevantFeeder->feed(Argument::cetera())->shouldNotBeCalled();

        $this->registerPlaceholderFeeder($aFeeder);
        $this->registerPlaceholderFeeder($anotherFeeder);
        $this->registerPlaceholderFeeder($anIrrelevantFeeder);
        $template = $this->getTemplateComputed($template, ['foo' => 'bar']);

        $template->subject->shouldBe('aSubjectWithAnotherSubject');
        $template->content->shouldBe('aContentWithAnotherContent');
    }
}
