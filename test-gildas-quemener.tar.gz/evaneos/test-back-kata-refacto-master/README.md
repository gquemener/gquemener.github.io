# Refactoring Kata Test

## Installing Dependencies

Dependencies are handled with composer.

Install them running:

``` bash
$ docker run --rm -ti -v "$PWD":/app --user "$(id -u):$(id -g)" composer install
```

## Running Tests

Tests are written using phpspec.

You can run the suite using the following commands:

``` bash
$ docker run --rm -ti -v "$PWD":/app -w /app php:5.5 vendor/bin/phpspec run
$ docker run --rm -ti -v "$PWD":/app -w /app php:7 vendor/bin/phpspec run
```

> Why not PHPUnit? Although it is possible, and totally fine, to do SpecBDD with PHPUnit,
> I've prefered to use a tool that's been designed for it. It comes with several benefit like class skeleton generator
> and smoother mocking api (https://gist.github.com/gquemener/5722064).

## Refactoring Philosophy

This code suffers from several common problems that arise on code after some time.

1. Not using php namespace
2. Requirement of an out-of-date php version
3. A `*Manager` class that knows how to handle many, if not all, the side of a feature
4. No dependency injection

### PHP Namespace

Namespaces exist in PHP since version 5.3, which means that there are around for almost 9 years,
there's really no reason not to use them!

The main problem being that classes and functions not defined in a namespace will be placed in PHP global namespace.

You may see this place as a wasteland where classes and functions comes from different parts of the whole system without
a real organization.

![PHP Wasteland](http://i0.kym-cdn.com/photos/images/newsfeed/001/041/398/6ea.gif)

Namespace gives bounded contexts to your classes and functions, it gives them a meaning and allows
a greater naming freedom.

Although you won't be able to silently override other classes and functions, it also restricts you to name them
as you want, pushing you to find other names or creating your own namespace mecanism (ie: prefixing name).

### Outdated PHP version

This package requires PHP from version 5.5.

Although it'd be a good idea to drop its support soon (5.5 was supported until July 2016), this isn't a trivial
change as it will impact other environments (CI, staging, production).

That's why the code has been designed to be backward compatible.

This let us time to setup a migration plan.

In order to keep things simple, we haven't manually checked scalar argument and return value types, although we should.

### The manager that knows all-the-things

Wether it's a controller or a manager, there's a tendency to put everything in the same place.

This leads to classes with uncontrolled complexity, with many responsibilities, making them more and more difficult to
maintain.

The idea of the refactoring here is to introduce placeholder feeders.

A placeholder feeder is a class (that implements the interface of the same name) which sole purpose is to... feed
specific placeholders.

From feeding all the template placeholders, the role of the `TemplateManager::getTemplateComputed` method
has became delegating this process to specialized classes.

We have broken a one method complexity into several, easy to test, easy to reason about, easy to maintain, classes.

Supporting new placeholder will no longer increase method complexity as we will create a new specialized class instead
of modifying an ever-growing method.

### Dependency Injection

Besides many problems that come with resolving dependencies from within a class (aka instantiating things in
the constructor), the major one is that we create a tight coupling between classes that have different purposes.

As we are unable to swap dependency implementations at runtime, we are unable to mock them.
Thus, we must extend the bounds of our unit tests (in our case here, we could need to setup a whole database) which
will make them harder to maintain and longer to run.

This problem is easy to fix, dependencies are defined as constructor arguments
and passed at runtime (see examples/example.php at line 41 for example).

We haven't defined interfaces for these repositories, although we could, in order to keep things simple.

We could also have used a full-featured dependency injection container,
like the [Symfony Component](https://github.com/symfony/dependency-injection) or
the [Pimple](https://github.com/silexphp/Pimple) minimalist implementation, but haven't, again to keep things simple.

### Side note on using public attributes

Public attributes are heavily used everywhere in this code base, especially in the model.

Although it eases the overall usage of the classes, it is considered as a bad practice because it opens object
to state modification to the whole world without being able to know why the change has been operated.

In this condition it is impossible to protect domain invariants and we could end up with objects
in an impossible or undesired state, which breaks core concepts of OOP.

We should instead have clearly named public methods, with according guards, and private attributes.

As the refactoring was focused on the `TemplateManager`, I have considered it was not necessary to extend
the boundaries of the exercise (but it would definitly needs to be done!).
