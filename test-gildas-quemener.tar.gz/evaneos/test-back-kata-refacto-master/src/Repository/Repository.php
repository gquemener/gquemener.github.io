<?php

namespace App\Repository;

interface Repository
{
    public function getById($id);
}
