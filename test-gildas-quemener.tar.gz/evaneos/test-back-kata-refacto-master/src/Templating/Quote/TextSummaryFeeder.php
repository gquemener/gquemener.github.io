<?php

namespace App\Templating\Quote;

use App\Templating\PlaceholderFeeder;
use App\Entity\Quote;

class TextSummaryFeeder implements PlaceholderFeeder
{
    const PLACEHOLDER = '[quote:summary]';

    /**
     * {@inheritdoc}
     */
    public function supports($text, array $data)
    {
        return false !== strpos($text, self::PLACEHOLDER)
            && isset($data['quote'])
            && $data['quote'] instanceof Quote;
    }

    /**
     * {@inheritdoc}
     */
    public function feed($text, array $data)
    {
        return str_replace(
            self::PLACEHOLDER,
            (string) $data['quote']->id,
            $text
        );
    }
}
