<?php

namespace App\Templating\Quote;

use App\Templating\PlaceholderFeeder;
use App\Entity\Quote;

class HtmlSummaryFeeder implements PlaceholderFeeder
{
    const PLACEHOLDER = '[quote:summary_html]';

    /**
     * {@inheritdoc}
     */
    public function supports($text, array $data)
    {
        return false !== strpos($text, self::PLACEHOLDER)
            && isset($data['quote'])
            && $data['quote'] instanceof Quote;
    }

    /**
     * {@inheritdoc}
     */
    public function feed($text, array $data)
    {
        return str_replace(
            self::PLACEHOLDER,
            sprintf('<p>%d</p>', $data['quote']->id),
            $text
        );
    }
}
