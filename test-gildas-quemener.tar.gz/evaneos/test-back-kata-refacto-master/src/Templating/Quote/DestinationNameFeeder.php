<?php

namespace App\Templating\Quote;

use App\Templating\PlaceholderFeeder;
use App\Entity\Quote;
use App\Repository\DestinationRepository;

class DestinationNameFeeder implements PlaceholderFeeder
{
    const PLACEHOLDER = '[quote:destination_name]';

    private $repository;

    public function __construct(DestinationRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * {@inheritdoc}
     */
    public function supports($text, array $data)
    {
        return false !== strpos($text, self::PLACEHOLDER)
            && array_key_exists('quote', $data)
            && $data['quote'] instanceof Quote;
    }

    /**
     * {@inheritdoc}
     */
    public function feed($text, array $data)
    {
        $destination = $this->repository->getById($data['quote']->destinationId);

        return str_replace(
            self::PLACEHOLDER,
            $destination->countryName,
            $text
        );
    }
}
