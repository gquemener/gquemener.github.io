<?php

namespace App\Templating\Quote;

use App\Templating\PlaceholderFeeder;
use App\Entity\Quote;
use App\Repository;

final class DestinationLinkFeeder implements PlaceholderFeeder
{
    const PLACEHOLDER = '[quote:destination_link]';

    private $quoteRepository;
    private $destinationRepository;
    private $siteRepository;

    public function __construct(
        Repository\QuoteRepository $quoteRepository,
        Repository\DestinationRepository $destinationRepository,
        Repository\SiteRepository $siteRepository
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->destinationRepository = $destinationRepository;
        $this->siteRepository = $siteRepository;
    }

    /**
     * {@inheritdoc}
     */
    public function supports($text, array $data)
    {
        return false !== strpos($text, self::PLACEHOLDER)
            && array_key_exists('quote', $data)
            && $data['quote'] instanceof Quote;
    }

    /**
     * {@inheritdoc}
     */
    public function feed($text, array $data)
    {
        $quote = $this->quoteRepository->getById($data['quote']->id);
        $destination = $this->destinationRepository->getById($data['quote']->destinationId);
        $site = $this->siteRepository->getById($data['quote']->siteId);

        return str_replace(
            self::PLACEHOLDER,
            sprintf(
                '%s/%s/quote/%d',
                $site->url,
                $destination->countryName,
                $quote->id
            ),
            $text
        );
    }
}
