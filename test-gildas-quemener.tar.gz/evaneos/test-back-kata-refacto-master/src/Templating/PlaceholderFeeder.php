<?php

namespace App\Templating;

interface PlaceholderFeeder
{
    /**
     * Whether this class can feed the provided placeholdered string.
     *
     * @param string $text
     * @param array $data
     *
     * @return bool
     */
    public function supports($text, array $data);

    /**
     * Feed the placeholder contained in the provided string.
     *
     * @param string $text
     * @param array $data
     *
     * @return string
     */
    public function feed($text, array $data);
}
