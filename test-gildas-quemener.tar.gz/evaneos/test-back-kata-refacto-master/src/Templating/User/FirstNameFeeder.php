<?php

namespace App\Templating\User;

use App\Templating\PlaceholderFeeder;
use App\Entity\User;
use App\Context\ApplicationContext;

class FirstNameFeeder implements PlaceholderFeeder
{
    const PLACEHOLDER = '[user:first_name]';

    private $appContext;

    public function __construct(ApplicationContext $appContext)
    {
        $this->appContext = $appContext;
    }

    /**
     * {@inheritdoc}
     */
    public function supports($text, array $data)
    {
        return false !== strpos($text, self::PLACEHOLDER);
    }

    /**
     * {@inheritdoc}
     */
    public function feed($text, array $data)
    {
        if (array_key_exists('user', $data) && $data['user'] instanceof User) {
            $user = $data['user'];
        } else {
            $user = $this->appContext->getCurrentUser();
        }

        return str_replace(
            self::PLACEHOLDER,
            $user->firstname,
            $text
        );
    }
}
