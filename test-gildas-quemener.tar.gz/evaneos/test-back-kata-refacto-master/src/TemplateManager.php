<?php

namespace App;

use App\Entity\Template;
use App\Context\ApplicationContext;
use App\Repository\QuoteRepository;
use App\Repository\SiteRepository;
use App\Repository\DestinationRepository;
use App\Entity\Quote;
use App\Templating\PlaceholderFeeder;

class TemplateManager
{
    private $placeholderFeeders = [];

    public function registerPlaceholderFeeder(PlaceholderFeeder $placeholderFeeder)
    {
        $this->placeholderFeeders[] = $placeholderFeeder;
    }

    public function getTemplateComputed(Template $tpl, array $data)
    {
        $replaced = clone($tpl);
        $replaced->subject = $this->computeText($replaced->subject, $data);
        $replaced->content = $this->computeText($replaced->content, $data);

        return $replaced;
    }

    private function computeText($text, array $data)
    {
        foreach ($this->placeholderFeeders as $feeder) {
            if ($feeder->supports($text, $data)) {
                $text = $feeder->feed($text, $data);
            }
        }

        return $text;
    }
}
