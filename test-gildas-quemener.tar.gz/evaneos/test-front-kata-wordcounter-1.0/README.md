Evaneos test-js
==

Explanations
--

The `wordCounter` function uses several piped functions to generate the expected output.

We will go through each of them now (spoiler alert: we'll use [MapReduce](https://en.wikipedia.org/wiki/MapReduce)!).

### Word splitting

First task is to split words. The concept of a word is here a bit more advanced
than "a suite of adjacent latin characters separated by space".

In fact, is considered a word any suite of latin characters that are separated by a space,
a dot, a coma, a hyphen or an apostrophe.

Thus, we use
the [`split`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/split) method
to break the string into an array and use
a [regular expression](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/RegExp)
that matches [any of these characters](https://regexper.com/#[\s\.\%2C\-']) as a separator.

### Filtering

We then [filter out](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/filter)
any value that have a length which is less than the provided threshold. 

We make sure to run this process as early as possible, in order to work faster with a cleaned result set.

### Lowercasing everything

Next step is to be case insensitive in our result set,
[mapping](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/map) each value to
its lowercased version.

### Aggregate the values into a result set

Thanks to the [`reduce`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce)
function, we are able to iterate through our words and create the result set as we go through them.

Conclusion
--

We have performed this process through a set of well defined, pure, independent functions.

That's neat! We have now became word counting experts!
