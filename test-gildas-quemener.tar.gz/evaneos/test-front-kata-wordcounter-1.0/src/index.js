const wordCounter = require('./wordCounter');


module.exports = {
    wordCounter,
};
