function wordCounter(text, minLength) {
    return text
        .split(/[\s\.\,\-']/)
        .filter((word) => word.length >= minLength)
        .map((word) => word.toLowerCase())
        .reduce((acc, word) => {
            if (acc.hasOwnProperty(word)) {
                return Object.assign({}, acc, {
                    [word]: acc[word] + 1
                });
            }

            return Object.assign({}, acc, {
                [word]: 1
            });
        }, {});
}

module.exports = wordCounter;
