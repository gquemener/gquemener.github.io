module.exports = [
    require('./french'),
    require('./russian'),
    require('./swedish'),
];
